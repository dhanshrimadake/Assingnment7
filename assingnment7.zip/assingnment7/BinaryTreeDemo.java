package assingnment7;

import java.util.Scanner;

public class BinaryTreeDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BinaryTreeClass<Integer> tree = new BinaryTreeClass<>();

        while (true) {
            System.out.println("1. Add\n" +
                    "2. PreOrder Traversal\n" +
                    "3. PostOrder Traversal\n" +
                    "4. Count Nodes\n" +
                    "5. Count Leaf Nodes\n" +
                    "6. Count Nodes with Specific Value\n" +
                    "7. Exit\n");

            switch (sc.nextInt()) {
                case 1:
                    System.out.print("Enter value to add: ");
                    tree.add(sc.nextInt());
                    break;
                case 2:
                    System.out.print("PreOrder Traversal: ");
                    tree.preOrderTraversal();
                    break;
                case 3:
                    System.out.print("PostOrder Traversal: ");
                    tree.postOrderTraversal();
                    break;
                case 4:
                    System.out.println("Number of Nodes: " + tree.countNodes());
                    break;
                case 5:
                    System.out.println("Number of Leaf Nodes: " + tree.countLeafNodes());
                    break;
                case 6:
                    System.out.print("Enter value to count: ");
                    int value = sc.nextInt();
                    System.out.println("Number of Nodes with value " + value + ": " + tree.countNodesWithValue(value));
                    break;
                case 7:
                    sc.close();
                    System.exit(0);
            }
        }
    }
}
